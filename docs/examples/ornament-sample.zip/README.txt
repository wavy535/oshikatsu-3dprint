OshiNest 装飾フレーム試作
更新後の/createでframe.oshinest.jsonを読み込んでください。
frame.zipに部品の3MFが入っています。単位mm。
実印刷・強度・最小肉厚・サポートは未検証。
写真と同等の装飾密度や曲面表現にはまだ到達していません。
